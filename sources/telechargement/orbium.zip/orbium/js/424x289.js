(function(orbium, undefined) {
	orbium.dimensions_424x289 = {
		"tile_size": 53,
		"marble_size": 17,
		"bar_height": 24,
		"gfx_path": "gfx/424x289/"
	};
})(typeof window == "object" ? window.orbium = window.orbium || {} : orbium);
