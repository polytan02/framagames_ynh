(function(orbium, undefined) {
	orbium.dimensions_1024x697 = {
		"tile_size": 128,
		"marble_size": 40,
		"bar_height": 57,
		"gfx_path": "gfx/1024x697/"
	};
})(typeof window == "object" ? window.orbium = window.orbium || {} : orbium);
