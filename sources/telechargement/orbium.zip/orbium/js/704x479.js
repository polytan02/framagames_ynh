(function(orbium, undefined) {
	orbium.dimensions_704x479 = {
		"tile_size": 88,
		"marble_size": 28,
		"bar_height": 39,
		"gfx_path": "gfx/704x479/"
	};
})(typeof window == "object" ? window.orbium = window.orbium || {} : orbium);
