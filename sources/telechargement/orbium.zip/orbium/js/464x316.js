(function(orbium, undefined) {
	orbium.dimensions_464x316 = {
		"tile_size": 58,
		"marble_size": 18,
		"bar_height": 26,
		"gfx_path": "gfx/464x316/"
	};
})(typeof window == "object" ? window.orbium = window.orbium || {} : orbium);
