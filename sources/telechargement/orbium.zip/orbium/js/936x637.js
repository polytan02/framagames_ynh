(function(orbium, undefined) {
	orbium.dimensions_936x637 = {
		"tile_size": 117,
		"marble_size": 37,
		"bar_height": 52,
		"gfx_path": "gfx/936x637/"
	};
})(typeof window == "object" ? window.orbium = window.orbium || {} : orbium);
