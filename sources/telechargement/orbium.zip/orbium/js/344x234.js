(function(orbium, undefined) {
	orbium.dimensions_344x234 = {
		"tile_size": 43,
		"marble_size": 13,
		"bar_height": 19,
		"gfx_path": "gfx/344x234/"
	};
})(typeof window == "object" ? window.orbium = window.orbium || {} : orbium);
